//
//  TH02_MobCompTests.swift
//  TH02_MobCompTests
//
//  Created by student on 22/09/25.
//

import Testing
@testable import TH02_MobComp

struct TH02_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

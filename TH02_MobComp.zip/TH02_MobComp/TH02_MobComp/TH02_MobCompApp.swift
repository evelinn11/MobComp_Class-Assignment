//
//  TH02_MobCompApp.swift
//  TH02_MobComp
//
//  Created by student on 22/09/25.
//

import SwiftUI

@main
struct TH02_MobCompApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

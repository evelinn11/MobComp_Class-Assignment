//
//  W01_CATests.swift
//  W01_CATests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_CA

struct W01_CATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

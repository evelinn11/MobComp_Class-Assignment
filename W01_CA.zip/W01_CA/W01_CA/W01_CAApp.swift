//
//  W01_CAApp.swift
//  W01_CA
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_CAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

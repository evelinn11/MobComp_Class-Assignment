//
//  TH03_Evelin_Alim_NatadjajaTests.swift
//  TH03_Evelin Alim NatadjajaTests
//
//  Created by student on 29/09/25.
//

import Testing
@testable import TH03_Evelin_Alim_Natadjaja

struct TH03_Evelin_Alim_NatadjajaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

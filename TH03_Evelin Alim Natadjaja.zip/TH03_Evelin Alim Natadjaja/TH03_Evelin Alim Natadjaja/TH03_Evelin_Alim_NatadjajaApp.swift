//
//  TH03_Evelin_Alim_NatadjajaApp.swift
//  TH03_Evelin Alim Natadjaja
//
//  Created by student on 29/09/25.
//

import SwiftUI

@main
struct TH03_Evelin_Alim_NatadjajaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

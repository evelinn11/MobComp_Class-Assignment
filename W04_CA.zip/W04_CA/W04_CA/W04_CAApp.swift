//
//  W04_CAApp.swift
//  W04_CA
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_CAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

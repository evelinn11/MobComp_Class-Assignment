//
//  W04_CATests.swift
//  W04_CATests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_CA

struct W04_CATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
